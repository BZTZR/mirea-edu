// Var. №4 Bilyalov Timur
#include <iostream>
#include <cmath>
using namespace std;
int main(){
  double a,b,c; //Определяем переменные квадратного уравнения вида ax² + bx + c = 0.
  char cmd; //Определяем переменную буквы отвечающую за определенное действие. Если D, то выводится имя и фамилия, если q - то вычисляем корни квадратного уравнения, если а - определяем переменные сторон прямоугольника и вычисляем его площадь
  cout<<"Enter a,b,c separated by space. ONLY 3 numbers. Otherwise, the program will stop working with Exit status 0.\n";
  cin>>a>>b>>c; //вводим числа
  cout<<"Enter only 1 letter D or q or a. Write ONLY ONE of these letters observing the case. Otherwise, the program will stop working with Exit status 0.\n";
  cin>>cmd; //ввдоим букву
  if (cmd == 'D'){//При букве D - выводится фамилия и имя
      cout<<"Bilyalov Timur\n";
  }
  else if (cmd == 'q'){ //При букве q - корни квадратного уравнения
      if (a == 0 && b == 0 && c == 0){
         cout<<"x is any real number"; // если a b c - нули, то х все действительные числа
      }
      else if(a == 0){
          if (b!=0){
           cout<<-c/b<<"- root x";   
          }// если а ноль а b нет, то вычисляем корень
          else{
           cout<<"There are no solutions";
          }//иначе корней нет
      }
      else{
        double dis = b*b -4*a*c;
        if (dis >0){
            cout<<"Two roots x1="<<(-b+sqrt(dis))/(2*a)<<" x2="<<(-b-sqrt(dis))/(2*a)<<endl;
        }//если все переменные не ноль, то при положительном дискриминанте выводится 2 корня
        else if (dis == 0){
            cout<<"One root x ="<<-b/(2*a)<<endl;
        }// если дискриминант ноль, то выводим только один возможный корень
        else{
            cout<<"There are no roots"<<endl; // иначе если отрицательный - корней нет
        }
      }
  }
  else if (cmd == 'a'){ //При букве a - определения 2 сторон прямоугольника и его площади
      double s1, s2;
      cout<<"Enter 2 sides of the rectangle in numbers separated by a space. ONLY 2 numbers. Otherwise, the program will stop working with Exit status 0.\n";
      cin>>s1>>s2;//определили переменные 2-ух сторон прямоугольника и ввели в них длины сторон
      cout<<"rectangle area = "<<s1*s2<<endl;//вывод площади прямоугольника
  }
}