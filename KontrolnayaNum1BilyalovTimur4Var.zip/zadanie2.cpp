// Var. №4 Bilyalov Timur
#include <iostream>
using namespace std;
int main(){
  double a, b, c; //определяем переменные
  cout<<"Enter 3 numbers separated by a space. For example: 2 2 2. The program accepts ONLY numbers separated by a space\n";
  cin>> a>> b>> c; //вводим переменные через пробел в одной строке. Только числа.
  cout<<9.6*a + 5.6*b - 16.8*c<<'\n'; //вывдоим результат выражения со значениями переменных определенных ранее.
}