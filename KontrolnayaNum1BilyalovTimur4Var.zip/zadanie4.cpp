// Var. №4 Bilyalov Timur
#include <iostream>
#include <cmath>
using namespace std;
int main(){
  int size;
  cout<<"Enter the size of array\n";
  cin>>size;
  int arr[size];
  cout<<"Enter "<<size<<" numbers and only numbers separated by spaces on one line or each number on a new line, otherwise the program will terminate or generate an error\n";
  for (int i = 0; i<size; i++){
    cin>>arr[i];   
  }
  for (int i = 0; i<size-1;i++){ //bubble sort method
      for(int j =0; j<size -i-1;j++){
          if(arr[j]>arr[j+1]){
              //exchange of elements
              int temp = arr[j];
              arr[j] = arr[j+1];
              arr[j+1] = temp;
          }
      }
  }
  cout<<"Sorted array made by bubble method: ";
  for (int i = 0; i < size; i++){ //Sorted array
      cout<<arr[i]<<" ";
  }   
}